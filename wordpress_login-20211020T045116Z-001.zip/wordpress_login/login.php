<?php include('db.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title>Login</title>
        <link rel="stylesheet" href="style.css"/>
    </head>

    <body>
        <div>
        <form method="POST" action="login.php" class="form">
        <?php include('errors.php'); ?>
        <h1 class="login-title">Login</h1>
        Username: <input type="text" class="login-input" name="username" placeholder="UserName" value="<?php echo $username; ?>" required/><br>
        Password: <input type="password" class="login-input" name="password" placeholder="Password" required/></br>
        <input type="submit" name="login" value="Login" class="login-button">
        </form>

        </div>
    </body>
</html>