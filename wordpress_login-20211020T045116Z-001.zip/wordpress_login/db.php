<?php
    session_start();
    $username="";
    $firstname="";
    $lastname="";
    $email="";
    $gender="";
    $city="";
    $address="";
    $mobile="";
    $password="";
    $conpassword="";
    $errors = array();
    $con = mysqli_connect('localhost','root','','mc_word');
    if(mysqli_connect_errno()){
        echo "Failed to coonect to database: " . mysqli_connect_error(); 
    }else{
        if(isset($_POST['submit'])){
            $username = mysqli_real_escape_string($con,$_POST['username']);
            $firstname = mysqli_real_escape_string($con,$_POST['firstname']);
            $lastname = mysqli_real_escape_string($con,$_POST['lastname']);
            $email = mysqli_real_escape_string($con,$_POST['email']);
            $gender = mysqli_real_escape_string($con,$_POST['gender']);
            $city = mysqli_real_escape_string($con,$_POST['city']);
            $address = mysqli_real_escape_string($con,$_POST['address']);
            $mobile = mysqli_real_escape_string($con,$_POST['mobile']);
            $password = mysqli_real_escape_string($con,$_POST['password']);
            $conpassword = mysqli_real_escape_string($con,$_POST['repassword']);
    
            //if (empty($username)) { array_push($errors, "Username is required"); }
            if (empty($lastname)) { array_push($errors, "Lastname is required"); }
            if (empty($email)) { array_push($errors, "Email is required"); }
            if (empty($gender)) { array_push($errors, "Gender is required"); }
            if (empty($city)) { array_push($errors, "City is required"); }
            if (empty($address)) { array_push($errors, "Address is required"); }
            if (empty($mobile)) { array_push($errors, "Mobile number is required"); }
            if (empty($password)) { array_push($errors, "Password is required"); }
            if (empty($conpassword)) { array_push($errors, "Confirm password is required"); }
            
            if (empty($username)) { array_push($errors, "Username is required"); 
            }elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($username))){
                array_push($errors,"Username should contains only alphabets!");
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
                array_push($errors, "Invalid email format");
            } 
            
            if(!preg_match('/^[0-9]{10}+$/', $mobile)){
                array_push($errors, "Mobile number must contains 10 digits");
            }

            if ($password != $conpassword) {
                array_push($errors, "The two passwords do not match");
            }elseif(strlen($password) <= '8'){
            array_push($errors, "Password length should be 8!");
            }elseif(!preg_match("#[0-9]+#",$_POST["password"])) {
            array_push($errors, "Your Password Must Contain At Least 1 Number !");
            }elseif(!preg_match("#[A-Z]+#",$_POST["password"])) {
                array_push($errors, "Your Password Must Contain At Least 1 Capital Letter !");
            }elseif(!preg_match("#[a-z]+#",$_POST["password"])) {
                array_push($errors,"Your Password Must Contain At Least 1 Lowercase Letter !");
            }elseif(!preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $_POST["password"])) {
                array_push($errors,"Your Password Must Contain At Least 1 Special Character !");
            }
    
            $user_check_query = "SELECT * FROM user WHERE username='$username' LIMIT 1";
            $result = mysqli_query($con, $user_check_query);
            $user = mysqli_fetch_assoc($result);
            if ($user) { // if user exists
                if ($user['username'] === $username) {
                  array_push($errors, "Username already exists");
                }
            }
            if (count($errors) == 0) {
                $pass = $password;//encrypt the password before saving in the database
          
                $query = "INSERT INTO user (username,first_name, last_name, mobile_number, email_id,password,
                gender,Address,city) VALUES('$username','$firstname', '$lastname', '$mobile', '$email','$pass','$gender', '$address','$city')";
                mysqli_query($con, $query);
                $_SESSION['username'] = $username;
                $_SESSION['success'] = "You are now logged in";
                //header('location: index.php');
            }
        }

        if(isset($_POST['login'])){
            $username = mysqli_real_escape_string($con,$_POST['username']);
            $password = mysqli_real_escape_string($con,$_POST['password']);
            if (empty($username)) {
                array_push($errors, "Username is required");
            }
            if (empty($password)) {
                array_push($errors, "Password is required");
            }
            if (count($errors) == 0) {
                $pass = $password;
                $query = "SELECT * FROM user WHERE username='$username' AND password='$pass'";
                $results = mysqli_query($con, $query);
                if (mysqli_num_rows($results) == 1) {
                  $_SESSION['username'] = $username;
                  $_SESSION['success'] = "You are now logged in";
                  header('location: index.php');
                }else {
                    array_push($errors, "Wrong username/password combination");
                }
            }
        }
        
    }
    

    


?>