<?php include('db.php'); ?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title>Registration</title>
        <link rel="stylesheet" href="style.css"/>
    </head>

    </body>
       
        <div>
            <form class="form" action="registration.php" method="post">
            <?php include('errors.php'); ?>
        <h1 class="login-title">Registration</h1>
        Username: <input type="text" class="login-input" name="username" placeholder="UserName" value="<?php echo $username; ?>" required/></br>
        Firstname: <input type="text" class="login-input" name="firstname" placeholder="First Name" value="<?php echo $firstname; ?>" required/></br>
        Lastname: <input type="text" class="login-input" name="lastname" placeholder="Last Name" value="<?php echo $lastname; ?>"  required/></br>
        Email-id: <input type="text" class="login-input" name="email" placeholder="Email-id" value="<?php echo $email; ?>" required/></br>
        
        Mobile-number: <input type="text" class="login-input" name="mobile" placeholder="Mobile Number" value="<?php echo $mobile; ?>" required/></br>
        Password: <input type="password" autocomplete="on" class="login-input" name="password" placeholder="Password" required/></br>
        Confirm Password: <input type="password" autocomplete="on" class="login-input" name="repassword" placeholder="Re-enter Password" required/></br>
        Gender:
        <input type="radio" name="gender"
        <?php if (isset($gender) && $gender=="female") echo "checked";?>
        value="female">Female
        <input type="radio" name="gender" checked
        <?php if (isset($gender) && $gender=="male") echo "checked";?>
        value="male">Male</br>
        Address: <textarea name="address" rows="5" cols="40" requireq></textarea></br>
        City: <select name="city" id="select" requireq>  
        <option value="Select" name="city" requireq>Select</option>
            <option value="Surat">Surat</option>
            <option value="Valsad">Valsad</option>  
            <option value="Bardoli">Bardoli</option>  
            <option value="Ahmedabad">Ahmedabad</option>  
            <option value="Vadodara">Vadodara</option>  
        </select>   </br>
        <input type="submit" name="submit" value="Register" class="login-button">
        <input type="reset" name="reset" value="Reset" class="login-button">
        </form>
        </div>

    </body>
</html>